﻿/*
Copyright (c) 2013, Maik Schreiber
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Toolbar {
	internal class Toolbar {
		internal enum Mode {
			TOOLBAR, FOLDER
		}

		private const float BUTTON_SPACING = 1;
		private const float PADDING = 3;
		private const float DEFAULT_X = 300;
		private const float DEFAULT_Y = 300;
		private const float DEFAULT_WIDTH = 250;
		private const float DEFAULT_HEIGHT_FOLDER = 100;

		internal event Action onChange;
		internal event Action onSkinChange;

		private delegate void ButtonPositionCalculatedHandler(Button button, Vector2 position);

		private bool Visible {
			set {
				if (value != visible_) {
					if (!value) {
						rectLocked = true;
						buttonOrderLocked = true;
						dropdownMenu = null;
						folderSettingsDialog = null;
						hookButtonOrderDraggables(false);
					}

					visible_ = value;
				}
			}
			get {
				return visible_;
			}
		}
		private bool visible_ = true;

		private bool Enabled {
			set {
				if (value != enabled_) {
					if (!value) {
						rectLocked = true;
						buttonOrderLocked = true;
						dropdownMenu = null;
						folderSettingsDialog = null;
						hookButtonOrderDraggables(false);
					}

					enabled_ = value;
				}
			}
			get {
				return enabled_;
			}
		}
		private bool enabled_ = true;

		private bool UseKSPSkin {
			set {
				if (value != useKSPSkin_) {
					useKSPSkin_ = value;
					fireSkinChange();
				}
			}
			get {
				return useKSPSkin_;
			}
		}
		private bool useKSPSkin_;

		private Mode mode;
		private Toolbar parentToolbar;
		private Rectangle rect;
		private Draggable draggable;
		private Resizable resizable;
		private List<Button> buttons = new List<Button>();
		private HashSet<string> visibleButtonIds = new HashSet<string>();
		private Button dropdownMenuButton;
		private PopupMenu dropdownMenu;
		private bool rectLocked = true;
		private bool buttonOrderLocked = true;
		private bool autoHide;
		private bool autoHidden;
		private Vector2 rectPositionBeforeAutoHide;
		private Color autoHideUnimportantButtonAlpha = Color.white;
		private Button mouseHoverButton;
		private float savedMaxWidth = DEFAULT_WIDTH;
		private bool showBorder = true;
		private Dictionary<Draggable, Rectangle> buttonOrderDraggables = new Dictionary<Draggable, Rectangle>();
		private DropMarker buttonOrderDropMarker;
		private Button draggedButton;
		private Rect draggedButtonRect;
		private Button buttonOrderHoveredButton;
		private List<string> savedButtonOrder = new List<string>();
		private EditorLock editorLockToolbar = new EditorLock("ToolbarPlugin_toolbar");
		private EditorLock editorLockMenu = new EditorLock("ToolbarPlugin_menu");
		private EditorLock editorLockDrag = new EditorLock("ToolbarPlugin_drag");
		private EditorLock editorLockReorder = new EditorLock("ToolbarPlugin_buttonReorder");
		private Dictionary<string, Toolbar> folders = new Dictionary<string, Toolbar>();
		private Dictionary<Button, Toolbar> folderButtons = new Dictionary<Button, Toolbar>();
		private Dictionary<string, FolderSettings> savedFolderSettings = new Dictionary<string, FolderSettings>();
		private FolderSettingsDialog folderSettingsDialog;

		internal Toolbar(Mode mode = Mode.TOOLBAR, Toolbar parentToolbar = null) {
			this.mode = mode;
			this.parentToolbar = parentToolbar;

			autoHideUnimportantButtonAlpha.a = 0.4f;

			rect = new Rectangle(new Rect(DEFAULT_X, DEFAULT_Y, DEFAULT_WIDTH, float.MinValue));

			if (mode == Mode.TOOLBAR) {
				dropdownMenuButton = Button.createToolbarDropdown();
				dropdownMenuButton.OnClick += (e) => toggleDropdownMenu();
				buttons.Add(dropdownMenuButton);

				draggable = new Draggable(rect, PADDING,
					(pos) => !getRect(dropdownMenuButton).shift(new Vector2(rect.x + PADDING, rect.y + PADDING)).Contains(pos) && !resizable.HandleRect.Contains(pos));
				resizable = new Resizable(rect, PADDING,
					(pos) => !getRect(dropdownMenuButton).shift(new Vector2(rect.x + PADDING, rect.y + PADDING)).Contains(pos));

				draggable.OnDrag += (e) => toolbarDrag();
				resizable.OnResize += toolbarResize;
			}
		}

		private void toolbarDrag() {
			if (!draggable.Dragging) {
				fireChange();
			}
		}

		private void toolbarResize() {
			if (resizable.Resizing) {
				float maxButtonWidth = buttons.Where(b => b.EffectivelyVisible).Max(b => b.Size.x);
				if (rect.width < (maxButtonWidth + PADDING * 2)) {
					rect.width = maxButtonWidth + PADDING * 2;
				}
				float minHeight = getMinHeightForButtons();
				if (rect.height < minHeight) {
					rect.height = minHeight;
				}
			} else {
				rect.width = getMinWidthForButtons();
				rect.height = getMinHeightForButtons();
				savedMaxWidth = rect.width;
				fireChange();
			}
		}

		internal void draw() {
			// only show toolbar if there is at least one visible button
			// that is not the drop-down menu button
			if (Visible &&
				((mode == Mode.FOLDER) || buttons.Any((b) => !b.Equals(dropdownMenuButton) && b.EffectivelyVisible))) {

				forceAutoSizeIfButtonVisibilitiesChanged();
				autoSize();

				if (mode == Mode.FOLDER) {
					autoPositionFolder();
				}

				if (autoHide && (dropdownMenu == null)) {
					handleAutoHide();
				}

				int oldDepth = GUI.depth;

				GUI.depth = -99;
				drawToolbarBorder();

				GUI.depth = -100;
				if (buttonOrderDropMarker != null) {
					buttonOrderDropMarker.draw();
				}

				GUISkin oldSkin = GUI.skin;
				if (UseKSPSkin) {
					GUI.skin = HighLogic.Skin;
				}
				drawButtons();
				GUI.skin = oldSkin;

				foreach (Toolbar folder in folders.Values) {
					folder.draw();
				}

				if (Enabled && rectLocked && buttonOrderLocked && (dropdownMenu == null)) {
					drawButtonToolTips();
				}

				if (dropdownMenu != null) {
					dropdownMenu.draw();
				}

				if (folderSettingsDialog != null) {
					folderSettingsDialog.draw();
				}

				GUI.depth = oldDepth;
			}

			Vector2 mousePos = Utils.getMousePosition();
			editorLockToolbar.draw(rect.contains(mousePos));
			editorLockMenu.draw((dropdownMenu != null) && dropdownMenu.Rect.Contains(mousePos));
			editorLockDrag.draw(!rectLocked);
			editorLockReorder.draw(!buttonOrderLocked);
		}

		private void autoPositionFolder() {
			// at this point, we should already have a good width/height

			if (parentToolbar.isSingleColumn()) {
				// positioning to right of parent toolbar
				rect.x = parentToolbar.rect.x + parentToolbar.rect.width + BUTTON_SPACING;
				float origX = rect.x;
				rect.y = parentToolbar.rect.y + (parentToolbar.rect.height - rect.height) / 2;
				rect.clampToScreen(0);
				// clamping to screen moved it to the left -> position to left of parent toolbar
				if (rect.x < origX) {
					rect.x = parentToolbar.rect.x - rect.width - BUTTON_SPACING;
					rect.clampToScreen(0);
				}
			} else {
				// position above parent toolbar
				rect.x = parentToolbar.rect.x + (parentToolbar.rect.width - rect.width) / 2;
				rect.y = parentToolbar.rect.y - rect.height - BUTTON_SPACING;
				float origY = rect.y;
				rect.clampToScreen(0);
				// clamping to screen moved it to the bottom -> position below parent toolbar
				if (rect.y > origY) {
					rect.y = parentToolbar.rect.y + parentToolbar.rect.height + BUTTON_SPACING;
					rect.clampToScreen(0);
				}
			}
		}

		private void handleAutoHide() {
			if (rect.contains(Utils.getMousePosition()) ||
				buttons.Any(b => b.Important) ||
				folders.Values.Any(f => f.Visible)) {

				if (autoHidden) {
					rect.x = rectPositionBeforeAutoHide.x;
					rect.y = rectPositionBeforeAutoHide.y;
					autoHidden = false;
				}
			} else {
				if (!autoHidden) {
					if (rect.x <= 0) {
						// left screen edge
						rectPositionBeforeAutoHide = new Vector2(rect.x, rect.y);
						rect.x = -rect.width + PADDING;
						autoHidden = true;
					} else if (rect.x >= (Screen.width - rect.width)) {
						// right screen edge
						rectPositionBeforeAutoHide = new Vector2(rect.x, rect.y);
						rect.x = Screen.width - PADDING;
						autoHidden = true;
					} else if (rect.y <= 0) {
						// top screen edge
						rectPositionBeforeAutoHide = new Vector2(rect.x, rect.y);
						rect.y = -rect.height + PADDING;
						autoHidden = true;
					} else if (rect.y >= (Screen.height - rect.height)) {
						// bottom screen edge
						rectPositionBeforeAutoHide = new Vector2(rect.x, rect.y);
						rect.y = Screen.height - PADDING;
						autoHidden = true;
					}
				}
			}
		}

		private bool shouldAutoHide() {
			return autoHide && !autoHidden && !rect.contains(Utils.getMousePosition()) &&
				((rect.x <= 0) || (rect.x >= (Screen.width - rect.width)) || (rect.y <= 0) || (rect.y >= (Screen.height - rect.height)));
		}

		private void autoSize() {
			if (rect.width < 0) {
				rect.width = DEFAULT_WIDTH;
				rect.width = getMinWidthForButtons();
				savedMaxWidth = rect.width;
			}
			if (rect.height < 0) {
				rect.height = getMinHeightForButtons();
			}

			if (!autoHidden) {
				rect.clampToScreen(PADDING);
			}
		}

		private float getMinWidthForButtons() {
			if (mode == Mode.FOLDER) {
				int count = buttons.Count((b) => !b.Equals(dropdownMenuButton) && b.EffectivelyVisible);
				if (count == 0) {
					return DEFAULT_WIDTH;
				} else {
					// make it roughly a square
					int columns = Mathf.CeilToInt(Mathf.Sqrt(count));
					// they're all the same size, so let's just take the first one
					Button firstVisibleButton = buttons.First((b) => !b.Equals(dropdownMenuButton) && b.EffectivelyVisible);
					float buttonWidth = firstVisibleButton.Size.x;
					return buttonWidth * columns + BUTTON_SPACING * (columns - 1) + PADDING * 2;
				}
			} else {
				float width = 0;
				calculateButtonPositions((button, pos) => {
					float currentWidth = pos.x + button.Size.x;
					if (currentWidth > width) {
						width = currentWidth;
					}
				});
				width += PADDING;
				return width;
			}
		}

		private float getMinHeightForButtons() {
			if ((mode == Mode.FOLDER) && (buttons.Count((b) => !b.Equals(dropdownMenuButton) && b.EffectivelyVisible) == 0)) {
				return DEFAULT_HEIGHT_FOLDER;
			} else {
				float height = 0;
				calculateButtonPositions((button, pos) => {
					float currentHeight = pos.y + button.Size.y;
					if (currentHeight > height) {
						height = currentHeight;
					}
				});
				height += PADDING;
				return height;
			}
		}

		private void calculateButtonPositions(ButtonPositionCalculatedHandler buttonPositionCalculatedHandler) {
			float x = PADDING;
			float y = PADDING;
			float lineHeight = float.MinValue;
			float widestLineWidth = float.MinValue;
			float currentLineWidth = 0;
			foreach (Button button in buttons) {
				if (button.EffectivelyVisible && !button.Equals(dropdownMenuButton)) {
					if (((x + button.Size.x) > (rect.width - PADDING)) && (lineHeight > 0)) {
						x = PADDING;
						y += lineHeight + BUTTON_SPACING;
						lineHeight = float.MinValue;
						if (currentLineWidth > widestLineWidth) {
							widestLineWidth = currentLineWidth;
						}
						currentLineWidth = 0;
					}
					if (button.Size.y > lineHeight) {
						lineHeight = button.Size.y;
					}
					buttonPositionCalculatedHandler(button, new Vector2(x, y));

					x += button.Size.x + BUTTON_SPACING;
					currentLineWidth += ((currentLineWidth > 0) ? BUTTON_SPACING : 0) + button.Size.x;
				}
			}
			if (currentLineWidth > widestLineWidth) {
				widestLineWidth = currentLineWidth;
			}

			// calculate position of drop-down menu button
			if (dropdownMenuButton != null) {
				if (y == PADDING) {
					// all buttons on a single line
					buttonPositionCalculatedHandler(dropdownMenuButton, new Vector2(x + 2, (lineHeight - dropdownMenuButton.Size.y) / 2 + PADDING));
				} else {
					// multiple lines
					buttonPositionCalculatedHandler(dropdownMenuButton, new Vector2((widestLineWidth - dropdownMenuButton.Size.x) / 2 + PADDING, y + lineHeight + BUTTON_SPACING + 2));
				}
			}
		}

		private void drawToolbarBorder() {
			if (showBorder || !rectLocked || !buttonOrderLocked) {
				Color oldColor = GUI.color;
				if (shouldAutoHide() && !autoHidden && (dropdownMenu == null)) {
					GUI.color = autoHideUnimportantButtonAlpha;
				}
				GUILayout.BeginArea(rect.Rect, GUI.skin.box);
				GUILayout.EndArea();
				GUI.color = oldColor;
			}
		}

		private void drawButtons() {
			// must create a copy because Button.draw() also handles the button click,
			// which can potentially modify our list of buttons
			Dictionary<Button, Rect> buttonsToDraw = new Dictionary<Button, Rect>();
			calculateButtonPositions((button, pos) => {
				Rect buttonRect = button.Equals(draggedButton) ? draggedButtonRect : new Rect(rect.x + pos.x, rect.y + pos.y, button.Size.x, button.Size.y);
				buttonsToDraw.Add(button, buttonRect);
			});
			
			bool shouldHide = shouldAutoHide();
			Button currentMouseHoverButton = null;
			Vector2 mousePos = Utils.getMousePosition();
			foreach (KeyValuePair<Button, Rect> entry in buttonsToDraw) {
				Button button = entry.Key;
				Rect buttonRect = entry.Value;
				Color oldColor = GUI.color;
				if (shouldHide && !autoHidden && !button.Important && (dropdownMenu == null)) {
					GUI.color = autoHideUnimportantButtonAlpha;
				}
				button.draw(buttonRect, ((Enabled && rectLocked && buttonOrderLocked) || button.Equals(dropdownMenuButton)) && !isPauseMenuOpen());
				GUI.color = oldColor;

				if (buttonRect.Contains(mousePos)) {
					currentMouseHoverButton = button;
				}
			}

			handleMouseHover(currentMouseHoverButton);
		}

		private void handleMouseHover(Button currentMouseHoverButton) {
			if ((mouseHoverButton == null) && (currentMouseHoverButton != null)) {
				currentMouseHoverButton.mouseEnter();
			} else if ((mouseHoverButton != null) && (currentMouseHoverButton == null)) {
				mouseHoverButton.mouseLeave();
			} else if ((mouseHoverButton != null) && (currentMouseHoverButton != null) && !currentMouseHoverButton.Equals(mouseHoverButton)) {
				mouseHoverButton.mouseLeave();
				currentMouseHoverButton.mouseEnter();
			}
			mouseHoverButton = currentMouseHoverButton;
		}

		private bool isPauseMenuOpen() {
			// PauseMenu.isOpen may throw NullReferenceException on occasion, even if HighLogic.LoadedScene==GameScenes.FLIGHT
			try {
				return (HighLogic.LoadedScene == GameScenes.FLIGHT) && PauseMenu.isOpen;
			} catch {
				return false;
			}
		}

		private void forceAutoSizeIfButtonVisibilitiesChanged() {
			HashSet<string> newVisibleButtonIds = new HashSet<string>();
			foreach (Button button in buttons.Where(b => b.EffectivelyVisible)) {
				newVisibleButtonIds.Add(button.ns + "." + button.id);
			}
			if (!newVisibleButtonIds.SetEquals(visibleButtonIds)) {
				Debug.Log("button visibilities have changed, forcing auto-size");
				visibleButtonIds = newVisibleButtonIds;

				if (isSingleLine()) {
					if (autoHidden) {
						// docked at right screen edge -> keep it that way by moving to screen edge
						if (rectPositionBeforeAutoHide.x >= (Screen.width - rect.width)) {
							rectPositionBeforeAutoHide.x = Screen.width;
						}
					} else {
						// docked at right screen edge -> keep it that way by moving to screen edge
						if (rect.x >= (Screen.width - rect.width)) {
							rect.x = Screen.width;
						}
					}
				} else {
					if (autoHidden) {
						// docked at bottom screen edge -> keep it that way by moving to screen edge
						if (rectPositionBeforeAutoHide.y >= (Screen.height - rect.height)) {
							rectPositionBeforeAutoHide.y = Screen.height;
						}
					} else {
						// docked at bottom screen edge -> keep it that way by moving to screen edge
						if (rect.y >= (Screen.height - rect.height)) {
							rect.y = Screen.height;
						}
					}
				}

				// expand width to last saved width, then resize for buttons, and expand height to fit new buttons
				rect.width = savedMaxWidth;
				rect.width = getMinWidthForButtons();
				rect.height = getMinHeightForButtons();

				if (!autoHidden) {
					rect.clampToScreen(PADDING);
				}

				fireChange();
			}
		}

		private bool isSingleLine() {
			if (buttons.Count(b => b.EffectivelyVisible) > 0) {
				float maxButtonHeight = buttons.Where(b => b.EffectivelyVisible).Max(b => b.Size.y);
				return rect.height <= (maxButtonHeight + PADDING * 2);
			} else {
				return true;
			}
		}

		private bool isSingleColumn() {
			if (buttons.Count(b => b.EffectivelyVisible) > 0) {
				float maxButtonWidth = buttons.Where(b => b.EffectivelyVisible).Max(b => b.Size.x);
				return rect.width <= (maxButtonWidth + PADDING * 2);
			} else {
				return true;
			}
		}

		internal Vector2 getPosition(Button button) {
			Vector2 position = new Vector2(float.MinValue, float.MinValue);
			bool done = false;
			calculateButtonPositions((b, pos) => {
				if (!done && b.Equals(button)) {
					position.x = pos.x - PADDING;
					position.y = pos.y - PADDING;
					done = true;
				}
			});
			return position;
		}

		internal Rect getRect(Button button) {
			Rect rect = new Rect(float.MinValue, float.MinValue, float.MinValue, float.MinValue);
			bool done = false;
			calculateButtonPositions((b, pos) => {
				if (!done && b.Equals(button)) {
					rect = new Rect(pos.x - PADDING, pos.y - PADDING, b.Size.x, b.Size.y);
					done = true;
				}
			});
			return rect;
		}

		private void drawButtonToolTips() {
			foreach (Button button in buttons) {
				button.drawToolTip();
			}
		}

		internal void update() {
			if (draggable != null) {
				draggable.update();
			}
			if (resizable != null) {
				resizable.update();
			}

			if (dropdownMenu != null) {
				if ((Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1) || Input.GetMouseButtonDown(2)) && !dropdownMenu.contains(Utils.getMousePosition())) {
					dropdownMenu = null;
				}
				if (isPauseMenuOpen()) {
					dropdownMenu = null;
				}
			}

			if (buttonOrderDraggables.Count() > 0) {
				foreach (Draggable d in new List<Draggable>(buttonOrderDraggables.Keys)) {
					d.update();
				}
			}
		}

		internal void add(Button button) {
			// destroy old button with the same ID
			Button oldButton = buttons.SingleOrDefault(b => (b.ns == button.ns) && (b.id == button.id));
			if (oldButton != null) {
				oldButton.Destroy();
			}
			// same with any folders
			Toolbar folder = folders.Values.SingleOrDefault(f => f.buttons.Any(b => (b.ns == button.ns) && (b.id == button.id)));
			if (folder != null) {
				oldButton = folder.buttons.SingleOrDefault(b => (b.ns == button.ns) && (b.id == button.id));
				if (oldButton != null) {
					oldButton.Destroy();
				}
			}

			string buttonId = button.ns + "." + button.id;
			string folderId = savedFolderSettings.Where(kv => kv.Value.buttons.Contains(buttonId)).Select(kv => kv.Key).SingleOrDefault();
			if ((folderId != null) && folders.ContainsKey(folderId)) {
				folders[folderId].add(button);
			} else {
				button.OnDestroy += buttonDestroyed;

				buttons.Add(button);

				sortButtons();
			}
		}

		private void sortButtons() {
			if (dropdownMenuButton != null) {
				buttons.Remove(dropdownMenuButton);
			}

			buttons.Sort((b1, b2) => {
				string id1 = b1.ns + "." + b1.id;
				string id2 = b2.ns + "." + b2.id;
				if (mode == Mode.TOOLBAR) {
					int idx1 = savedButtonOrder.IndexOf(id1);
					int idx2 = savedButtonOrder.IndexOf(id2);
					if ((idx1 >= 0) && (idx2 >= 0)) {
						return idx1 - idx2;
					} else if ((idx1 >= 0) && (idx2 < 0)) {
						return -1;
					} else if ((idx1 < 0) && (idx2 >= 0)) {
						return 1;
					}
				}
				return StringComparer.CurrentCultureIgnoreCase.Compare(id1, id2);
			});

			if (dropdownMenuButton != null) {
				buttons.Add(dropdownMenuButton);
			}
		}

		private void remove(Button button) {
			button.OnDestroy -= buttonDestroyed;
			buttons.Remove(button);
			if (folderButtons.ContainsKey(button)) {
				folderButtons.Remove(button);
			}
		}

		private void buttonDestroyed(DestroyEvent e) {
			remove(e.button);
		}

		internal void loadSettings(ConfigNode parentNode, GameScenes scene) {
			// hide these
			dropdownMenu = null;
			folderSettingsDialog = null;
			// deactivate these
			rectLocked = true;
			draggable.Enabled = false;
			resizable.Enabled = false;
			buttonOrderLocked = true;
			// pretend we're not auto-hidden right now
			autoHidden = false;
			// enable ourselves
			Enabled = true;
			// hide folders
			foreach (Toolbar folder in folders.Values) {
				folder.Visible = false;
			}
			// pretend that nothing was visible until now
			visibleButtonIds.Clear();

			if (parentNode.HasNode("toolbar")) {
				foreach (Toolbar folder in new List<Toolbar>(folders.Values)) {
					deleteFolder(folder);
				}
				savedFolderSettings.Clear();

				ConfigNode toolbarNode = parentNode.GetNode("toolbar");
				ConfigNode settingsNode = toolbarNode.HasNode(scene.ToString()) ? toolbarNode.GetNode(scene.ToString()) : toolbarNode;
				rect.x = settingsNode.get("x", DEFAULT_X);
				rect.y = settingsNode.get("y", DEFAULT_Y);
				rect.width = settingsNode.get("width", DEFAULT_WIDTH);
				rect.height = settingsNode.get("height", 0f);
				autoHide = settingsNode.get("autoHide", false);
				showBorder = settingsNode.get("drawBorder", true);
				useKSPSkin_ = settingsNode.get("useKSPSkin", false);
				savedButtonOrder = settingsNode.get("buttonOrder", "").Split(new char[] { ',' }).ToList();

				if (settingsNode.HasNode("folders")) {
					foreach (ConfigNode folderNode in settingsNode.GetNode("folders").nodes) {
						string folderId = folderNode.name;
						string toolTip = folderNode.get("toolTip", "");
						HashSet<string> buttonIds = new HashSet<string>(folderNode.get("buttons", "").Split(new char[] { ',' }));

						Toolbar folder = createFolder(folderId, toolTip, false);
						folder.UseKSPSkin = UseKSPSkin;
						folder.showBorder = showBorder;

						savedFolderSettings[folderId].buttons = buttonIds;
					}
				}

				// move existing buttons according to saved folder contents
				foreach (Button button in new List<Button>(buttons)) {
					string buttonId = button.ns + "." + button.id;
					string folderId = savedFolderSettings.SingleOrDefault(kv => kv.Value.buttons.Contains(buttonId)).Key;
					if (folderId != null) {
						moveButtonToFolder(button, folders[folderId]);
					}
				}
			}

			savedMaxWidth = rect.width;

			sortButtons();
		}

		internal void saveSettings(ConfigNode parentNode, GameScenes scene) {
			ConfigNode toolbarNode = parentNode.getOrCreateNode("toolbar");
			ConfigNode settingsNode = toolbarNode.getOrCreateNode(scene.ToString());
			settingsNode.overwrite("x", rect.x.ToString("F0"));
			settingsNode.overwrite("y", rect.y.ToString("F0"));
			settingsNode.overwrite("width", savedMaxWidth.ToString("F0"));
			settingsNode.overwrite("height", rect.height.ToString("F0"));
			settingsNode.overwrite("autoHide", autoHide.ToString());
			settingsNode.overwrite("drawBorder", showBorder.ToString());
			settingsNode.overwrite("useKSPSkin", UseKSPSkin.ToString());
			settingsNode.overwrite("buttonOrder", string.Join(",", savedButtonOrder.ToArray()));

			ConfigNode foldersNode = settingsNode.overwriteNode("folders");
			foreach (KeyValuePair<string, FolderSettings> entry in savedFolderSettings) {
				ConfigNode folderNode = foldersNode.getOrCreateNode(entry.Key);
				folderNode.overwrite("toolTip", entry.Value.toolTip ?? "");
				folderNode.overwrite("buttons", string.Join(",", entry.Value.buttons.ToArray()));
			}
			if (foldersNode.CountNodes == 0) {
				settingsNode.RemoveNode("folders");
			}
		}

		private void fireChange() {
			if (onChange != null) {
				onChange();
			}
		}

		private void fireSkinChange() {
			if (onSkinChange != null) {
				onSkinChange();
			}
		}

		private void toggleDropdownMenu() {
			if (dropdownMenu == null) {
				dropdownMenu = new PopupMenu(new Vector2(rect.x + PADDING + getPosition(dropdownMenuButton).x, rect.y + rect.height + BUTTON_SPACING));

				bool regularEntriesEnabled = rectLocked && buttonOrderLocked;

				Button createFolderButton = Button.createMenuOption("Create New Folder");
				createFolderButton.OnClick += (e) => createFolder();
				createFolderButton.Enabled = regularEntriesEnabled;
				dropdownMenu += createFolderButton;

				Button toggleRectLockButton = Button.createMenuOption(rectLocked ? "Unlock Position and Size" : "Lock Position and Size");
				toggleRectLockButton.OnClick += (e) => {
					rectLocked = !rectLocked;
					draggable.Enabled = !rectLocked;
					resizable.Enabled = !rectLocked;

					if (rectLocked) {
						fireChange();
					} else {
						autoHide = false;
						foreach (Toolbar folder in folders.Values) {
							folder.Visible = false;
						}
					}
				};
				toggleRectLockButton.Enabled = buttonOrderLocked;
				dropdownMenu += toggleRectLockButton;

				Button toggleButtonOrderLockButton = Button.createMenuOption(buttonOrderLocked ? "Unlock Button Order" : "Lock Button Order");
				toggleButtonOrderLockButton.OnClick += (e) => {
					buttonOrderLocked = !buttonOrderLocked;

					hookButtonOrderDraggables(!buttonOrderLocked);

					if (buttonOrderLocked) {
						fireChange();
					} else {
						autoHide = false;
					}
					foreach (Toolbar folder in folders.Values) {
						folder.Enabled = buttonOrderLocked;
					}
				};
				toggleButtonOrderLockButton.Enabled = rectLocked;
				dropdownMenu += toggleButtonOrderLockButton;

				Button toggleAutoHideButton = Button.createMenuOption(autoHide ? "Deactivate Auto-Hide at Screen Edge" : "Activate Auto-Hide at Screen Edge");
				toggleAutoHideButton.OnClick += (e) => {
					autoHide = !autoHide;
					fireChange();
				};
				toggleAutoHideButton.Enabled = regularEntriesEnabled;
				dropdownMenu += toggleAutoHideButton;

				Button toggleDrawBorderButton = Button.createMenuOption(showBorder ? "Hide Border" : "Show Border");
				toggleDrawBorderButton.OnClick += (e) => {
					showBorder = !showBorder;
					foreach (Toolbar folder in folders.Values) {
						folder.showBorder = showBorder;
					}
					fireChange();
				};
				toggleDrawBorderButton.Enabled = regularEntriesEnabled;
				dropdownMenu += toggleDrawBorderButton;

				Button toggleKSPSkinButton = Button.createMenuOption(UseKSPSkin ? "Use Unity 'Smoke' Skin" : "Use KSP Skin");
				toggleKSPSkinButton.OnClick += (e) => {
					UseKSPSkin = !UseKSPSkin;
					foreach (Toolbar folder in folders.Values) {
						folder.UseKSPSkin = UseKSPSkin;
					}
					fireChange();
				};
				toggleKSPSkinButton.Enabled = regularEntriesEnabled;
				dropdownMenu += toggleKSPSkinButton;

				Button aboutButton = Button.createMenuOption("About the Toolbar Plugin");
				aboutButton.OnClick += (e) => Application.OpenURL(ToolbarManager.FORUM_THREAD_URL);
				aboutButton.Enabled = regularEntriesEnabled;
				dropdownMenu += aboutButton;

				// close drop-down menu when player clicks on an option
				foreach (Button option in dropdownMenu.Options) {
					option.OnClick += (e) => dropdownMenu = null;
				}
			} else {
				dropdownMenu = null;
			}
		}

		private void hookButtonOrderDraggables(bool enabled) {
			if (enabled) {
				calculateButtonPositions((button, pos) => {
					if (!button.Equals(dropdownMenuButton)) {
						Rectangle buttonRect = new Rectangle(new Rect(rect.x + pos.x, rect.y + pos.y, button.Size.x, button.Size.y));
						Draggable draggable = new Draggable(buttonRect, 0, null);
						draggable.Enabled = true;
						draggable.OnDrag += buttonDrag;
						buttonOrderDraggables.Add(draggable, buttonRect);
					}
				});

				buttonOrderDropMarker = new DropMarker();
			} else {
				foreach (Draggable d in buttonOrderDraggables.Keys) {
					d.OnDrag -= buttonDrag;
				}
				buttonOrderDraggables.Clear();
				buttonOrderDropMarker = null;
			}
			draggedButton = null;
		}

		private void buttonDrag(DragEvent e) {
			if (e.draggable.Dragging) {
				Rectangle dragRect = buttonOrderDraggables[e.draggable];

				if (draggedButton == null) {
					draggedButton = buttons.SingleOrDefault(b => getRect(b).shift(new Vector2(rect.x + PADDING, rect.y + PADDING)).Equals(dragRect.Rect));
				}

				if (draggedButton != null) {
					draggedButtonRect = dragRect.Rect;

					Vector2 mousePos = Utils.getMousePosition();
					buttonOrderHoveredButton = buttons.SingleOrDefault(
						b => !b.Equals(draggedButton) && !b.Equals(dropdownMenuButton) && getRect(b).shift(new Vector2(rect.x + PADDING, rect.y + PADDING)).Contains(mousePos));
					if (buttonOrderHoveredButton != null) {
						Rect hoveredButtonRect = getRect(buttonOrderHoveredButton).shift(new Vector2(rect.x + PADDING, rect.y + PADDING));
						Toolbar folder = folderButtons.ContainsKey(buttonOrderHoveredButton) ? folderButtons[buttonOrderHoveredButton] : null;
						if ((folder != null) &&
							// disallow folders in folders
							!folderButtons.ContainsKey(draggedButton)) {

							float widthOneThird = hoveredButtonRect.width / 3;
							float middleX = hoveredButtonRect.x + widthOneThird;
							if (new Rect(middleX, hoveredButtonRect.y, widthOneThird, hoveredButtonRect.height).Contains(mousePos)) {
								// middle section
								buttonOrderDropMarker.Rect = hoveredButtonRect;
							} else if (new Rect(hoveredButtonRect.x, hoveredButtonRect.y, widthOneThird, hoveredButtonRect.height).Contains(mousePos)) {
								// left section
								buttonOrderDropMarker.Rect = new Rect(
									hoveredButtonRect.x - DropMarker.MARKER_LINE_WIDTH, hoveredButtonRect.y,
									DropMarker.MARKER_LINE_WIDTH, hoveredButtonRect.height);
							} else {
								// right section
								buttonOrderDropMarker.Rect = new Rect(
									hoveredButtonRect.x + hoveredButtonRect.width, hoveredButtonRect.y,
									DropMarker.MARKER_LINE_WIDTH, hoveredButtonRect.height);
							}
						} else {
							bool leftSide = new Rect(hoveredButtonRect.x, hoveredButtonRect.y, hoveredButtonRect.width / 2, hoveredButtonRect.height).Contains(mousePos);
							// TODO: improve this to show a horizontal drop marker instead of a vertical one for single-column toolbars
							buttonOrderDropMarker.Rect = new Rect(
								leftSide ? (hoveredButtonRect.x - DropMarker.MARKER_LINE_WIDTH) : (hoveredButtonRect.x + hoveredButtonRect.width),
								hoveredButtonRect.y,
								DropMarker.MARKER_LINE_WIDTH, hoveredButtonRect.height);
						}
					}
					buttonOrderDropMarker.Visible = buttonOrderHoveredButton != null;
				}
			} else {
				if ((draggedButton != null) && (buttonOrderHoveredButton != null)) {
					Rect hoveredButtonRect = getRect(buttonOrderHoveredButton).shift(new Vector2(rect.x + PADDING, rect.y + PADDING));
					Vector2 mousePos = Utils.getMousePosition();
					bool leftSide = false;
					bool intoFolder = false;
					Toolbar folder = folderButtons.ContainsKey(buttonOrderHoveredButton) ? folderButtons[buttonOrderHoveredButton] : null;
					if (folder != null) {
						float widthOneThird = hoveredButtonRect.width / 3;
						float middleX = hoveredButtonRect.x + widthOneThird;
						if (new Rect(middleX, hoveredButtonRect.y, widthOneThird, hoveredButtonRect.height).Contains(mousePos)) {
							intoFolder = true;
						} else if (new Rect(hoveredButtonRect.x, hoveredButtonRect.y, widthOneThird, hoveredButtonRect.height).Contains(mousePos)) {
							leftSide = true;
						}
					} else {
						leftSide = new Rect(hoveredButtonRect.x, hoveredButtonRect.y, hoveredButtonRect.width / 2, hoveredButtonRect.height).Contains(mousePos);
					}

					if (intoFolder) {
						moveButtonToFolder(draggedButton, folder);
					} else {
						int draggedButtonIdx = buttons.IndexOf(draggedButton);
						int hoveredButtonIdx = buttons.IndexOf(buttonOrderHoveredButton);
						if (!leftSide) {
							hoveredButtonIdx++;
						}

						buttons.RemoveAt(draggedButtonIdx);
						if (hoveredButtonIdx > draggedButtonIdx) {
							hoveredButtonIdx--;
						}
						buttons.Insert(hoveredButtonIdx, draggedButton);
					}

					savedButtonOrder = buttons.Where(b => !b.Equals(dropdownMenuButton)).Select(b => b.ns + "." + b.id).ToList();

					Dictionary<string, FolderSettings> newSavedFolderSettings = new Dictionary<string, FolderSettings>();
					foreach (KeyValuePair<string, Toolbar> entry in folders) {
						HashSet<string> folderButtonIds = new HashSet<string>(entry.Value.buttons.Select(b => b.ns + "." + b.id));
						newSavedFolderSettings.Add(entry.Key, new FolderSettings() {
							toolTip = savedFolderSettings[entry.Key].toolTip,
							buttons = folderButtonIds
						});
					}
					savedFolderSettings = newSavedFolderSettings;

					fireChange();
				}

				forceAutoSizeIfButtonVisibilitiesChanged();

				// reset draggables, drop marker, and dragged button
				hookButtonOrderDraggables(false);
				hookButtonOrderDraggables(true);
			}
		}

		private void moveButtonToFolder(Button button, Toolbar folder) {
			remove(button);
			folder.add(button);
		}

		private void createFolder() {
			folderSettingsDialog = new FolderSettingsDialog("New Folder");
			folderSettingsDialog.OnOkClicked += () => {
				createFolder("folder_" + new System.Random().Next(int.MaxValue), folderSettingsDialog.ToolTip, true);
				folderSettingsDialog = null;
			};
			folderSettingsDialog.OnCancelClicked += () => folderSettingsDialog = null;
		}

		private void editFolder(Toolbar folder) {
			string folderId = folders.Single(kv => kv.Value.Equals(folder)).Key;
			string toolTip = savedFolderSettings[folderId].toolTip;
			folderSettingsDialog = new FolderSettingsDialog(toolTip);
			folderSettingsDialog.OnOkClicked += () => {
				toolTip = folderSettingsDialog.ToolTip;
				savedFolderSettings[folderId].toolTip = toolTip;
				Button folderButton = folderButtons.Single(kv => kv.Value.Equals(folder)).Key;
				folderButton.ToolTip = toolTip;
				folderSettingsDialog = null;
				fireChange();
			};
			folderSettingsDialog.OnCancelClicked += () => folderSettingsDialog = null;
		}

		private Toolbar createFolder(string id, string toolTip, bool visible) {
			if (visible) {
				// close all other folders first
				foreach (Toolbar folder in folders.Values) {
					folder.Visible = false;
				}
			}

			Toolbar newFolder = new Toolbar(Mode.FOLDER, this);
			newFolder.Visible = visible;
			folders.Add(id, newFolder);

			Button folderButton = new Button(Button.NAMESPACE_INTERNAL, id, this);
			folderButton.TexturePath = "000_Toolbar/folder";
			folderButton.ToolTip = toolTip;
			folderButton.OnClick += (e) => {
				switch (e.MouseButton) {
					case 0:
						newFolder.Visible = !newFolder.Visible;
						if (newFolder.Visible) {
							foreach (Toolbar otherFolder in folders.Values.Where(f => !f.Equals(newFolder))) {
								otherFolder.Visible = false;
							}
						}
						break;

					case 1:
						openFolderButtonDropdownMenu(newFolder, getPosition(folderButton) + new Vector2(rect.x + PADDING, rect.y + PADDING + folderButton.Size.y + BUTTON_SPACING));
						break;
				}
			};
			folderButtons.Add(folderButton, newFolder);
			add(folderButton);

			savedFolderSettings.Add(id, new FolderSettings() {
				buttons = new HashSet<string>(),
				toolTip = toolTip
			});

			return newFolder;
		}

		private void openFolderButtonDropdownMenu(Toolbar folder, Vector2 pos) {
			dropdownMenu = new PopupMenu(pos);

			Button editButton = Button.createMenuOption("Edit Folder Settings");
			editButton.OnClick += (e) => editFolder(folder);
			dropdownMenu += editButton;

			Button deleteButton = Button.createMenuOption("Delete Folder");
			deleteButton.OnClick += (e) => deleteFolder(folder);
			dropdownMenu += deleteButton;

			// close drop-down menu when player clicks on an option
			foreach (Button option in dropdownMenu.Options) {
				option.OnClick += (e) => dropdownMenu = null;
			}
		}

		private void deleteFolder(Toolbar folder) {
			string folderId = folders.Single(kv => kv.Value.Equals(folder)).Key;
			folders.Remove(folderId);

			savedFolderSettings.Remove(folderId);

			Button folderButton = folderButtons.Single(kv => kv.Value.Equals(folder)).Key;
			folderButton.Destroy();

			foreach (Button b in new List<Button>(folder.buttons)) {
				folder.remove(b);
				add(b);
			}
		}
	}
}
